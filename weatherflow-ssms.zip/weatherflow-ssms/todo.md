# ✅ Overall TODO list

- [ ] Week 1: Data analysis (EDA)
- [ ] Week 2: T-SQL + SQL Server
- [ ] Week 3: ETL Pipeline (Python + SQL Server)
- [ ] Week 4: ML model + dashboard
