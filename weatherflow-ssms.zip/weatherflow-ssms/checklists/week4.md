# 📅 Week 4 – ML model + dashboard
- [ ] Prepare data for modeling: train/test split
- [ ] Build linear regression model
- [ ] Evaluate model (MSE, R2)
- [ ] (Optional) Create dashboard with predictions
