# 📅 Week 2 – SQL Server (T-SQL)
- [ ] Install SQL Server Express + SSMS
- [ ] Create weather database
- [ ] Create and populate weather_data table
- [ ] Write SQL queries: SELECT, WHERE, GROUP BY
- [ ] Analyze daily/monthly average temperature
