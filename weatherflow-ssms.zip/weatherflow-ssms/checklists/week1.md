# 📅 Week 1 – EDA (Exploratory Data Analysis)
- [ ] Understand CSV weather dataset structure
- [ ] Load data using pandas
- [ ] Clean data (missing values, duplicates)
- [ ] Compute: mean, median, min, max
- [ ] Visualize temperature over time
