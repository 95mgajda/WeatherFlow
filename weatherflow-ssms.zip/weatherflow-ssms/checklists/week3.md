# 📅 Week 3 – ETL and pipeline
- [ ] Build a Python function to clean data
- [ ] Connect Python to SQL Server using pyodbc
- [ ] Write ETL pipeline: load CSV, clean, insert into SQL Server
- [ ] Automate process with schedule
- [ ] Add logging to track ETL steps
